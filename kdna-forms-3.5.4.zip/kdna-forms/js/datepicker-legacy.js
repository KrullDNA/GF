/**
 * Apply legacy options to DatePickers within Legacy Forms.
 */
kform.addFilter( 'kform_datepicker_options_pre_init', function( optionsObj, formId, inputId, $element ) {
	var kdna_legacy = window.kdna_legacy_multi;

	if ( ! kdna_legacy ) {
		return optionsObj;
	}
	if ( !kdna_legacy[ formId ] || kdna_legacy[ formId ] !== '1' ) {
		return optionsObj;
	}

	var $ = window.jQuery;
	var isPreview = $( '#preview_form_container' ).length > 0;
	var isRTL = window.getComputedStyle( $element[ 0 ], null ).getPropertyValue( 'direction' ) === 'rtl';
	var overrides = {
		showOtherMonths: false,
		beforeShow: function( input, inst ) {
			inst.dpDiv[0].classList.remove( 'kform-theme-datepicker' );
			inst.dpDiv[0].classList.remove( 'kdna-theme' );
			inst.dpDiv[0].classList.remove( 'kform-theme' );
			inst.dpDiv[0].classList.remove( 'kform-legacy-datepicker' );
			inst.dpDiv[0].classList.remove( 'kform-theme--framework' );
			inst.dpDiv[0].classList.remove( 'kform-theme--foundation' );
			inst.dpDiv[0].classList.remove( 'kform-theme--orbital' );
			inst.dpDiv[0].classList.add( 'kform-legacy-datepicker' );

			if ( isRTL && isPreview ) {
				var $inputContainer = $( input ).closest( '.kfield' );
				var rightOffset = $( document ).outerWidth() - ( $inputContainer.offset().left + $inputContainer.outerWidth() );
				inst.dpDiv[ 0 ].style.right = rightOffset + 'px';
			}

			if ( isPreview ) {
				inst.dpDiv[0].classList.add( 'kform-preview-datepicker' );
			}
			return ! this.suppressDatePicker;
		}
	};

	return Object.assign( optionsObj, overrides );
}, -10 );
