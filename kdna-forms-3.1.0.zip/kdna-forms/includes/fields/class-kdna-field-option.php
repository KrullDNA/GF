<?php

if ( ! class_exists( 'KDNAForms' ) ) {
	die();
}


class KDNA_Field_Option extends KDNA_Field {

	public $type = 'option';

	function get_form_editor_field_settings() {
		return array(
			'product_field_setting',
			'option_field_type_setting',
			'conditional_logic_field_setting',
			'prepopulate_field_setting',
			'label_setting',
			'admin_label_setting',
			'label_placement_setting',
			'default_value_setting',
			'placeholder_setting',
			'description_setting',
			'css_class_setting',
		);
	}

	public function get_form_editor_field_title() {
		return esc_attr__( 'Option', 'kdnaforms' );
	}

	/**
	 * Returns the field's form editor description.
	 *
	 * @since 2.5
	 *
	 * @return string
	 */
	public function get_form_editor_field_description() {
		return esc_attr__( 'Allows users to select options for products created by a product field.', 'kdnaforms' );
	}

	/**
	 * Returns the field's form editor icon.
	 *
	 * This could be an icon url or a kform-icon class.
	 *
	 * @since 2.5
	 *
	 * @return string
	 */
	public function get_form_editor_field_icon() {
		return 'kform-icon--misc';
	}

}

KDNA_Fields::register( new KDNA_Field_Option() );